export default function About() {
  return (
    <main className="container page-section">
      <div className="row justify-content-center">
        <div className="col-lg-9">
          <p className="eyebrow mb-1">GET TO KNOW US</p>
          <h1 className="section-title">About Green Basket</h1>
          <p className="lead">We are a student-led group with a shared interest in practical products and thoughtful shopping.</p>
          <h2 className="h4 mt-4">Meet the owners</h2>
          <p>Green Basket is created and managed by [Your Group Members' Names]. We work together on product selection, customer service, and the online store.</p>
          <h2 className="h4 mt-4">Our story</h2>
          <p>The idea for Green Basket started when we noticed how small everyday items can make routines more convenient and enjoyable. We wanted to create a simple online shop where people can discover useful essentials in one place. Our goal is to make browsing easy and give every visitor a friendly shopping experience.</p>
          <div className="about-note mt-4">Replace the bracketed text with the names of your actual group members before submitting.</div>
        </div>
      </div>
    </main>
  );
}