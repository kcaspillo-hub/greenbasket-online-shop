import { products } from "../data/products";
import ProductCard from "../components/ProductCard";

export default function Shop() {
  return (
    <main className="container page-section">
      <p className="eyebrow mb-1">THE GREEN BASKET COLLECTION</p>
      <h1 className="section-title">Shop all products</h1>
      <p className="text-secondary mb-4">Browse our collection of everyday essentials.</p>
      <div className="row g-4">
        {products.map(product => <ProductCard key={product.id} product={product} />)}
      </div>
    </main>
  );
}