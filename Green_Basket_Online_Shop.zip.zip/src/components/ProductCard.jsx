import { Link } from "react-router-dom";

export default function ProductCard({ product }) {
  return (
    <div className="col-sm-6 col-lg-4">
      <div className="card product-card h-100">
        <img src={product.image} className="card-img-top product-image" alt={product.name} />
        <div className="card-body d-flex flex-column">
          <small className="text-uppercase category-label">{product.category}</small>
          <h5 className="card-title mt-2">{product.name}</h5>
          <p className="price mb-3">₱{product.price.toFixed(2)}</p>
          <Link className="btn btn-outline-success mt-auto" to={`/product/${product.id}`}>View Product</Link>
        </div>
      </div>
    </div>
  );
}