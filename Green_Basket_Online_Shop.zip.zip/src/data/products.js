export const products = [
  {
    id: 1,
    name: "Reusable Water Bottle",
    price: 249,
    category: "Daily Essentials",
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=900&q=80",
    description: "A durable reusable bottle for school, work, and everyday adventures."
  },
  {
    id: 2,
    name: "Canvas Tote Bag",
    price: 199,
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1772890753143-24991d807710?auto=format&fit=crop&w=900&q=80",
    description: "A simple and roomy tote bag for books, groceries, and daily essentials."
  },
  {
    id: 3,
    name: "Ceramic Coffee Mug",
    price: 179,
    category: "Home",
    image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=900&q=80",
    description: "A comfortable ceramic mug for your favorite hot or cold drink."
  },
  {
    id: 4,
    name: "Desk Plant",
    price: 299,
    category: "Home",
    image: "https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=900&q=80",
    description: "A little touch of green to brighten your study table or workspace."
  },
  {
    id: 5,
    name: "Notebook Set",
    price: 149,
    category: "Stationery",
    image: "https://images.unsplash.com/photo-1531346878377-a5be20888e57?auto=format&fit=crop&w=900&q=80",
    description: "A handy notebook set for notes, plans, sketches, and ideas."
  }
];